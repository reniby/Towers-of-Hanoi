class disc {
  constructor(x, w, h, n) {
    this.x = x;
    this.w = w;
    this.h = h;
    this.num = n;
  }
}